package com.peisia.burgercat;

import java.util.ArrayList;

public class Kiosk {
	ArrayList<Goods> basket = new ArrayList<>();
	
	public void run() {
		loop:
		while(true) {
			Command cmd = new Command(); 
			String c = cmd.getCommand("명령을 입력해주세요. [1:버거,2:사이드,3:음료,4:디저트,c:계산,e:종료] :");
			switch(c) {
			case "1":
				ProcBurger pb = new ProcBurger();
				pb.run(basket);
				break;
			case "2":
				ProcSide ps = new ProcSide();
				ps.run(basket);
				break;
			case "3":
				ProcDrink pd = new ProcDrink();
				pd.run(basket);
				break;
			case "4":
				ProcDessert pds = new ProcDessert();
				pds.run(basket);
				break;
			case "c":
				System.out.println("계산하기");
				//장바구니 확인
				System.out.print("[장바구니: ");
				for(Goods g:basket) {
					System.out.print(g.name+" ");
				}
				System.out.println("]");
				//todo
				//계산
				int sum = 0;
				for(Goods g:basket) {
					sum=sum+g.price;
				}
				System.out.println("계산하실 금액은 "+sum+"원 입니다.");
				break;
			case "e":
				System.out.println("프로그램 종료");
				break loop;
			}
		}
	}
}
