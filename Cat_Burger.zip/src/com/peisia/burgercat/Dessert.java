package com.peisia.burgercat;

public class Dessert extends Food{

	public Dessert(int price, String name) {
		super(price, name);
		// TODO Auto-generated constructor stub
	}

}
