package com.peisia.burgercat;

public class Figure extends Goods{

	public Figure(int price, String name) {
		super(price, name);
	}

}
