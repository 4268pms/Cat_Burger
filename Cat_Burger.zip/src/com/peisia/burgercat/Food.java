package com.peisia.burgercat;

public class Food extends Goods{
	public String expiryDate;

	public Food(int price, String name) {
		super(price, name);
		// TODO Auto-generated constructor stub
	}
	
}
