package com.peisia.burgercat;

import java.util.ArrayList;

public class ProcSide {
	public void run(ArrayList<Goods> basket) {

		loop:
		while(true) {
			Command cmd = new Command(); 
			String c = cmd.getCommand("명령을 입력해주세요."
					+"[1:텍사스칠리프라이,2:치킨도넛한조각,3:앵그리너겟킹여덟조각,4:너겟킹여덟조각,"
					+"5:앵그리너겟킹,6:너겟킹,7:이십일치즈스틱,8:바삭킹,9:바삭킹여덟조각과소스,10:크리미모짜볼"
					+"11:코코넛쉬림프와스위트칠리소스,12:어니언링,13:쉐이킹프라이,14:치즈프라이,15:프렌치프라이"
					+"16:코울슬로,17:콘샐러드,18:시즈닝,19:사이드소스"
					+",c:취소,b:뒤로] :");
			
			switch(c) {
			case "1":
				System.out.println("텍사스칠리프라이 선택함");
				basket.add(new Side(1000,"텍사스칠리프라이"));
				break;
			case "2":
				System.out.println("치킨도넛한조각 선택함");
				basket.add(new Side(1000,"치킨도넛한조각"));
				break;
			case "3":
				System.out.println("앵그리너겟킹여덟조각 선택함");
				basket.add(new Side(1000,"앵그리너겟킹여덟조각"));
				break;
			case "4":
				System.out.println("너겟킹여덟조각 선택함");
				basket.add(new Side(1000,"너겟킹여덟조각"));
				break;
			case "5":
				System.out.println("앵그리너겟킹 선택함");
				basket.add(new Side(1000,"앵그리너겟킹"));
				break;
			case "6":
				System.out.println("너겟킹 선택함");
				basket.add(new Side(1000,"너겟킹"));
				break;
			case "7":
				System.out.println("이십일치즈스틱 선택함");
				basket.add(new Side(1000,"이십일치즈스틱"));
				break;
			case "8":
				System.out.println("바삭킹 선택함");
				basket.add(new Side(1000,"바삭킹"));
				break;
			case "9":
				System.out.println("바삭킹여덟조각과소스 선택함");
				basket.add(new Side(1000,"바삭킹여덟조각과소스"));
				break;
			case "10":
				System.out.println("크리미모짜볼 선택함");
				basket.add(new Side(1000,"크리미모짜볼"));
				break;
			case "11":
				System.out.println("코코넛쉬림프와스위트칠리소스 선택함");
				basket.add(new Side(1000,"코코넛쉬림프와스위트칠리소스"));
				break;
			case "12":
				System.out.println("어니언링 선택함");
				basket.add(new Side(1000,"어니언링"));
				break;
			case "13":
				System.out.println("쉐이킹프라이 선택함");
				basket.add(new Side(1000,"쉐이킹프라이"));
				break;
			case "14":
				System.out.println("치즈프라이 선택함");
				basket.add(new Side(1000,"치즈프라이"));
				break;
			case "15":
				System.out.println("프렌치프라이 선택함");
				basket.add(new Side(1000,"프렌치프라이"));
				break;
			case "16":
				System.out.println("코울슬로 선택함");
				basket.add(new Side(1000,"코울슬로"));
				break;
			case "17":
				System.out.println("콘샐러드 선택함");
				basket.add(new Side(1000,"콘샐러드"));
				break;
			case "18":
				System.out.println("시즈닝 선택함");
				basket.add(new Side(1000,"시즈닝"));
				break;
			case "19":
				System.out.println("사이드소스 선택함");
				basket.add(new Side(1000,"사이드소스"));
				break;
			case "c":
				System.out.println("취소");
				break loop;
			case "b":
				System.out.println("뒤로");
				break loop;
			}
		}
	}
}
