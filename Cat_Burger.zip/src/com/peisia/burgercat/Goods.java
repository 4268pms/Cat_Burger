package com.peisia.burgercat;

public class Goods {
	public int price;
	public String name;
	public Goods(int price, String name) {
		this.price = price;
		this.name = name;
	}
	
}
