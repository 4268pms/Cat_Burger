package com.peisia.burgercat;

public class Burger extends Food{

	public Burger(int price, String name) {
		super(price, name);
		// TODO Auto-generated constructor stub
	}

}
